import 'package:flutter/material.dart';
import 'main_page.dart';

class FAQPage extends StatefulWidget {
  FAQPage({Key? key}) : super(key: key);

  late String text;
  late String subtext;


  late VoidCallback onPressed;

   // AnimatedText({required this.text, required this.onPressed});
  @override
  State<FAQPage> createState() => _FAQPageState();
}

class _FAQPageState extends State<FAQPage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 0, 0, 8),
              child: Image.network(
                "https://i.pinimg.com/564x/01/7e/98/017e9883961e5aa207a6161de876aeba.jpg",
              ),
            ),
            const Text(
              "COMMON QUESTIONS",
              style: TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
            ),
            InkWell(
              child: GestureDetector(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 14.0, horizontal: 16.0),
                      child: Text(
                        "WHY ARE WEEKEND AND MONTH-END PRICES DIFFERENT?",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 14.0, horizontal: 16.0),
                      child: Text(
                        "CAN I RESCHEDULE MY MOVEMENT AFTER I HAVE PAID THE TOKEN AMOUNT?",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 14.0, horizontal: 16.0),
                      child: Text(
                        "MY MOVEMENT DATE IS NOT FIXED YET. HOW CAN I BOOK IN ADVANCE?",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 14.0, horizontal: 16.0),
                      child: Text(
                        "WILL THE MOVERS AND PACKERS ALSO DISMANTLE BEDS AND OTHER FURNITURE? ",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 14.0, horizontal: 16.0),
                      child: Text(
                        "WE HAVE VERY FEW ITEMS TO MOVE. THE QUOTATION IS VERY COSTLY.",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 14.0, horizontal: 16.0),
                      child: Text(
                        "IS PRELIMINARY INSPECTION REQUIRED BEFORE BOOKING THE MOVEMENT?",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 14.0, horizontal: 16.0),
                      child: Text(
                        "ARE THE PACKING MATERIALS ARE INCLUDED IN THE PACKAGE? ARE THERE ANY HIDDEN CHARGES?",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 14.0, horizontal: 16.0),
                      child: Text(
                        "DO YOU PROVIDE INSURANCE FOR THE GOODS?",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 14.0, horizontal: 16.0),
                      child: Text(
                        "CAN I ALSO MOVE MY CAR OR BIKE?",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 14.0, horizontal: 16.0),
                      child: Text(
                        "CITIES WHERE VRL PROVIDES VRL CARGO PACKERS AND MOVERS SERVICES",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 14.0, horizontal: 16.0),
                      child: Text(
                        "WHY SHOULD NOT I PAY ANY TOKEN IN ADVANCE BEFORE THE MOVE?",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }
}
