import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'main_page.dart';

class Book extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: const [
            TabBar(tabs: [Tab(child: Text("Intercity"),),Tab(child: Text("Intracity"),),Tab(child: Text("International"),),]),
          ],
        )
      ),
      body: Align(
        alignment: Alignment.topCenter,
        child: TabBarView(children: [
          BookPageChild(),
          BookPageChild(),
          BookPageChild(),
        ]),
      ),
    );
  }

}

class BookPageChild extends StatelessWidget {

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
   late final DateTime _selectedDate = DateTime.now();
   final _value = "-1";
   final String _textValue = '';


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Form(
          key: _formKey,
            child: Column(
              children: [
              Container(
                width: double.infinity,
                height: 160,
                decoration: const BoxDecoration(
                  shape: BoxShape.rectangle,
                  gradient: LinearGradient(colors: [
                    Colors.orange,
                    Colors.white54,

                  ], stops: [
                    0.4,
                    1.0,
                  ], begin: Alignment.topRight, end: Alignment.bottomRight),
                ),
                child: Column(
                  children: const [
                    Padding(
                      padding: EdgeInsets.fromLTRB(0, 20, 0, 0),
                      child: Text(
                        "Get Call Back In 10 Min",
                        style: TextStyle(
                          fontSize: 22.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                      child: Text(
                        "BOOK YOUR SHIFTING",
                        style: TextStyle(
                          fontSize: 28.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                child: Column(
                  children: [
                    SizedBox( height: 50, width: 330,

                      child: TextFormField(
                        decoration: InputDecoration(
                          labelText: 'Enter Your Name',
                          labelStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 15,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              color: Colors.black,
                              width: 1,
                            ),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              color: Colors.black54,
                              width: 3,
                            ),
                            borderRadius: BorderRadius.circular(18),
                          ),

                        ),


                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please Enter Your Name';
                          }
                          return null;
                        },



                      ),



                    ),
                    SizedBox(
                      height: 90, width: 330,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 20.0),
                        child: TextFormField(
                          decoration: InputDecoration(
                            labelText: 'Enter Your Email',
                            labelStyle: const TextStyle(
                              color: Colors.grey,
                              fontSize: 15,
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                color: Colors.black,
                                width: 1,
                              ),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                color: Colors.black54,
                                width: 3,
                              ),
                              borderRadius: BorderRadius.circular(18),
                            ),

                          ),


                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please Enter Email';
                            }
                            return null;
                          },



                        ),
                      ),
                    ),
                    SizedBox(
                      height: 56, width: 330,
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 2.0),
                        child: TextFormField(
                          decoration: InputDecoration(
                            labelText: 'Enter Mobile Number',
                            labelStyle: const TextStyle(
                              color: Colors.grey,
                              fontSize: 15,
                            ),
                            prefixText: '+91 ',
                            enabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                color: Colors.black,
                                width: 1,
                              ),
                              borderRadius: BorderRadius.circular(18),
                            ),

                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                color: Colors.black54,
                                width: 3,
                              ),
                              borderRadius: BorderRadius.circular(18),
                            ),


                          ),
                          keyboardType: TextInputType.phone,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please enter your mobile number';
                            } else if (value.length != 10) {
                              return 'Mobile number must be 10 digits long';
                            }
                            return null;
                          },
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () async {
                        final DateTime? picked = await showDatePicker(
                          context: context,
                          initialDate: _selectedDate != null ? _selectedDate : DateTime.now(),
                          firstDate: DateTime(2001) ,
                          lastDate: DateTime(2100),
                        );
                        if (picked != null && picked != _selectedDate) {
                          // setState(() {
                          //   _selectedDate = picked;
                          // });
                        }
                      },
                      child: IgnorePointer(
                        child: SizedBox(
                          height: 85, width: 330,
                          child: Padding(
                            padding: EdgeInsets.symmetric(vertical: 18.0),
                            child: TextFormField(
                              decoration: InputDecoration(
                                labelText: 'Date / Time',
                                labelStyle: const TextStyle(
                                  color: Colors.grey,
                                  fontSize: 15,
                                ),

                                enabledBorder: OutlineInputBorder(
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                    width: 1,
                                  ),
                                  borderRadius: BorderRadius.circular(18),
                                ),

                                focusedBorder: OutlineInputBorder(
                                  borderSide: const BorderSide(
                                    color: Colors.black54,
                                    width: 3,
                                  ),
                                  borderRadius: BorderRadius.circular(18),
                                ),


                                suffixIcon: Icon(Icons.calendar_today),
                              ),
                              controller: TextEditingController(
                                  text: _selectedDate != null ? "${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}" : ''),
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please enter moving date';
                                }
                                return null;
                              },
                            ),
                          ),
                        ),
                      ),
                    ),
                    // SizedBox(
                    //   height: 74, width: 330,
                    //   child: Padding(
                    //     padding: EdgeInsets.symmetric(vertical: 10.0),
                    //     child: Container(
                    //       child: DropdownButtonFormField(
                    //         decoration: InputDecoration(
                    //           labelText: 'Property Type',
                    //           labelStyle: TextStyle(
                    //             color: Colors.grey,
                    //             fontSize: 18,
                    //           ),
                    //           enabledBorder: OutlineInputBorder(
                    //             borderSide: BorderSide(
                    //               color: Colors.black,
                    //               width: 1,
                    //             ),
                    //             borderRadius: BorderRadius.circular(18),
                    //           ),
                    //           focusedBorder: OutlineInputBorder(
                    //             borderSide: BorderSide(
                    //               color: Colors.black54,
                    //               width: 3,
                    //             ),
                    //
                    //             borderRadius: BorderRadius.circular(18),
                    //           ),
                    //
                    //         ),
                    //         value: _value,
                    //         items: [
                    //           DropdownMenuItem(child: Text(""),value: "-1",),
                    //           DropdownMenuItem(child: Text("1BHK"),value: "2",),
                    //           DropdownMenuItem(child: Text("2BHK"),value: "3",),
                    //           DropdownMenuItem(child: Text("3BHK"),value: "4",),
                    //           DropdownMenuItem(child: Text("4BHK"),value: "5",),
                    //           DropdownMenuItem(child: Text("VILLA"),value: "6",),
                    //           DropdownMenuItem(child: Text("VEHICLE"),value: "7",),
                    //           DropdownMenuItem(child: Text("OFFICE"),value: "8",),
                    //           DropdownMenuItem(child: Text("COMMERCIAL MOVE"),value: "9",),
                    //           DropdownMenuItem(child: Text("INTERNATIONAL MOVE"),value: "10",),
                    //           DropdownMenuItem(child: Text("STORAGE SERVICE"),value: "11",),
                    //
                    //         ], onChanged: (String? value) {  },
                    //
                    //       ),
                    //     ),
                    //   ),
                    // ),
                    SizedBox(
                      height: 63, width: 330,
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 6.0),
                        child: TextFormField(
                          decoration: InputDecoration(
                            labelText: 'Move From (Your Address)',
                            labelStyle: const TextStyle(
                              color: Colors.grey,
                              fontSize: 15,
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                color: Colors.black,
                                width: 1,
                              ),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                color: Colors.black54,
                                width: 3,
                              ),
                              borderRadius: BorderRadius.circular(18),
                            ),

                          ),


                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Your Address';
                            }
                            return null;
                          },


                        ),
                      ),
                    ),
                    SizedBox(
                      height: 80, width: 330,
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 15.0),
                        child: TextFormField(
                          decoration: InputDecoration(
                            labelText: 'Move To (Your Destination)',
                            labelStyle: const TextStyle(
                              color: Colors.grey,
                              fontSize: 15,
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                color: Colors.black,
                                width: 1,
                              ),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                color: Colors.black54,
                                width: 3,
                              ),
                              borderRadius: BorderRadius.circular(18),
                            ),

                          ),


                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please Enter Your Destination)';
                            }
                            return null;
                          },
                        ),
                      ),
                    ),

                    const SizedBox(height: 10,width: double.infinity,),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: ElevatedButton(
                            onPressed: () {
                              if (_formKey.currentState!.validate()) {
                                // Process the text value here
                                print('Text value: $_textValue');
                              }
                            },
                            child: Text('Submit'),
                            style: ElevatedButton.styleFrom(
                              minimumSize: Size(300, 50),
                              primary: Colors.orange,
                              textStyle: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 25,
                              ),

                               padding: EdgeInsets.symmetric(horizontal: 25, vertical: 0), // Set button padding
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(18), // Set button border radius
                              ),
                            ),
                          ),
                        ),



                  ],
                ),

              )
                ],
          ),
        ),

      ),

    );
  }
}
